import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Step 1: Load data
data = pd.read_csv("hotels_list.csv")

# Step 2: Clean data
data['price'] = data['price'].fillna(data['price'].median())  # Fill missing prices
data['rating'] = data['rating'].apply(lambda x: float(x) if x else None)  # Clean ratings

# Step 3: Feature Extraction
data['price_range'] = pd.cut(data['price'], bins=[0, 100, 200, 500, float('inf')],
                             labels=['Budget', 'Mid-Range', 'Luxury', 'High-End'])

# Step 4: Normalize Numerical Data
scaler = MinMaxScaler()
data[['price', 'rating']] = scaler.fit_transform(data[['price', 'rating']])

# Step 5: Store to Database (simplified example)
# Write to SQL or NoSQL database, depending on structure requirements.
data.to_sql('hotels', con=database_connection, if_exists='replace')

# Step 6: Use for Recommendation System (Content-Based Filtering)
# Retrieve and recommend hotels based on user preferences.
